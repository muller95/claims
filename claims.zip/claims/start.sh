java -jar target/claims-1.0-SNAPSHOT-jar-with-dependencies.jar
